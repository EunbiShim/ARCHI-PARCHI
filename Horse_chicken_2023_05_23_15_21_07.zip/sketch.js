let images = []; 
let totalImages = 10; 

let currentIndex; 
function preload() {

  for (let i = 0; i < totalImages; i++) {
    images[i] = loadImage(`image_${i}.png`);
  }
}

function setup() {
  createCanvas(1920, 1080);
  background(255); 

  currentIndex = floor(random(totalImages));
}

function draw() {
  background(255);

  let x = width / 2 - images[currentIndex].width / 2;
  let y = height / 2 - images[currentIndex].height / 2;
  image(images[currentIndex], x, y);
}

function mouseClicked() {

  let newIndex = currentIndex;
  while (newIndex === currentIndex) {
    newIndex = floor(random(totalImages));
  }
  currentIndex = newIndex;
}